# =========================================================
# HIGHRIDGE CONSTRUCTION COMPANY
# WEEKLY PAYMENT SLIPS FOR 400 WORKERS
# R VERSION
# =========================================================

# ---------------------------------------------------------
# Step 1: Set the number of workers
# ---------------------------------------------------------
NUMBER_OF_WORKERS <- 400

# Ensure results can be reproduced
set.seed(123)


# ---------------------------------------------------------
# Step 2: Create a dynamic list of workers
# ---------------------------------------------------------
workers <- data.frame(
  id     = 1:NUMBER_OF_WORKERS,
  name   = paste0("Worker_", 1:NUMBER_OF_WORKERS),
  gender = sample(c("Male", "Female"),
                  NUMBER_OF_WORKERS,
                  replace = TRUE),
  salary = sample(5000:35000,
                  NUMBER_OF_WORKERS,
                  replace = TRUE),
  stringsAsFactors = FALSE
)


# ---------------------------------------------------------
# Function to determine employee level
# ---------------------------------------------------------
assign_employee_level <- function(salary, gender) {
  
  # Female workers earning between 7,500 and 30,000
  if (salary > 7500 && salary < 30000 && gender == "Female") {
    return("A5-F")
    
    # Workers earning between 10,000 and 20,000
  } else if (salary > 10000 && salary < 20000) {
    return("A1")
    
    # All other workers
  } else {
    return("B2")
  }
}


# ---------------------------------------------------------
# Step 3, 4, and 5
# Generate and print payment slips
# ---------------------------------------------------------
tryCatch({
  
  cat("\n")
  cat("============================================================\n")
  cat("           HIGHRIDGE CONSTRUCTION COMPANY\n")
  cat("          WEEKLY PAYMENT SLIPS FOR 400 WORKERS\n")
  cat("============================================================\n\n")
  
  # Step 3: Use a loop for all workers
  for (i in 1:nrow(workers)) {
    
    tryCatch({
      
      salary <- workers$salary[i]
      gender <- workers$gender[i]
      
      # Step 4: Apply conditional statements
      employee_level <- assign_employee_level(salary, gender)
      
      # Print the payment slip
      cat(sprintf("PAYMENT SLIP #%03d\n", workers$id[i]))
      cat("------------------------------------------------------------\n")
      cat(sprintf("Worker ID      : %d\n", workers$id[i]))
      cat(sprintf("Worker Name    : %s\n", workers$name[i]))
      cat(sprintf("Gender         : %s\n", gender))
      cat(sprintf("Salary         : $%s\n",
                  format(salary, big.mark = ",")))
      cat(sprintf("Employee Level : %s\n", employee_level))
      cat("------------------------------------------------------------\n\n")
      
    }, error = function(e) {
      cat(sprintf("Error processing worker %d: %s\n",
                  workers$id[i], e$message))
    })
  }
  
}, error = function(e) {
  cat(sprintf("An unexpected error occurred: %s\n", e$message))
})